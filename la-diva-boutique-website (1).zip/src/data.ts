/* =========================================================
   LA DIVA — contenu du site
   👉 Pour remplacer les photos : déposez vos images dans
   /public/images/ et modifiez simplement les chemins ci‑dessous.
   ========================================================= */

export const WA_NUMBER = "237679997844";
export const WA_DISPLAY = "+237 679 99 78 44";
export const WA_DEFAULT_MSG = "Bonjour LA DIVA, je souhaite passer une commande";

export const waLink = (msg: string = WA_DEFAULT_MSG) =>
  `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(msg)}`;

const px = (id: number, w = 800, h = 1100) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;

export const IMG = {
  hero: "/images/hero-boubou.jpg",
  wax: "/images/wax-outfit.jpg",
  kaba: "/images/cat-kaba.jpg",
  boubou: "/images/cat-boubou.jpg",
  pagne: "/images/cat-pagne.jpg",
  shoes: "/images/cat-shoes.jpg",
  ceremony: "/images/ceremony.jpg",
  robes: px(38315287),
  robeNoire: px(9927983),
  accessoires: px(27495832),
};

export const AVATARS = [
  px(1820575, 160, 160),
  px(7717254, 160, 160),
  px(6497112, 160, 160),
  px(38528495, 160, 160),
];

export const NAV = [
  { id: "accueil", label: "Accueil" },
  { id: "occasions", label: "Occasions" },
  { id: "categories", label: "Catégories" },
  { id: "produits", label: "Boutique" },
  { id: "temoignages", label: "Témoignages" },
  { id: "lookbook", label: "Lookbook" },
  { id: "collections", label: "Collections" },
  { id: "contact", label: "Contact" },
];

export const CATEGORIES = [
  { name: "Kaba", count: 48, img: IMG.kaba, tag: "Ngondo & kaba modernes" },
  { name: "Boubou", count: 36, img: IMG.boubou, tag: "Bazin, brodés, grand boubou" },
  { name: "Ensembles pagne", count: 72, img: IMG.pagne, tag: "Wax, Ankara, sur mesure" },
  { name: "Robes & hauts", count: 120, img: IMG.robes, tag: "Prêt-à-porter chic" },
  { name: "Chaussures", count: 85, img: IMG.shoes, tag: "Sandales, mules, escarpins" },
  { name: "Accessoires", count: 40, img: IMG.accessoires, tag: "Sacs, bijoux, foulards" },
];

export const MARQUEE = [
  "KABA",
  "BOUBOU",
  "WAX & ANKARA",
  "CHAUSSURES",
  "TENUES DE CÉRÉMONIE",
  "SUR MESURE",
  "NOUVEAUTÉS",
  "LIVRAISON RAPIDE",
];

export type Product = {
  name: string;
  category: string;
  group: "africain" | "pret" | "chaussures";
  price: number;
  oldPrice?: number;
  sizes: string[];
  img: string;
  badge?: string;
};

export const PRODUCTS: Product[] = [
  { name: "Kaba Royal Wax", category: "Kaba", group: "africain", price: 35000, sizes: ["S", "M", "L", "XL", "XXL"], img: IMG.kaba, badge: "Best-seller" },
  { name: "Boubou Bazin Brodé Or", category: "Boubou", group: "africain", price: 45000, sizes: ["Taille unique"], img: IMG.boubou, badge: "Nouveau" },
  { name: "Ensemble Ankara Sunset", category: "Ensembles pagne", group: "africain", price: 25000, oldPrice: 31000, sizes: ["S", "M", "L", "XL"], img: IMG.wax, badge: "-20%" },
  { name: "Robe Cérémonie Émeraude", category: "Tenues de cérémonie", group: "africain", price: 60000, sizes: ["Sur mesure"], img: IMG.ceremony, badge: "Cérémonie" },
  { name: "Robe Chic Urbaine", category: "Robes & hauts", group: "pret", price: 22000, sizes: ["XS", "S", "M", "L"], img: IMG.robes },
  { name: "Sandales Dorées Diva", category: "Chaussures", group: "chaussures", price: 18000, sizes: ["37", "38", "39", "40", "41"], img: IMG.shoes, badge: "Nouveau" },
];

export const fcfa = (n: number) => `${n.toLocaleString("fr-FR").replace(/\u202f|\u00a0/g, " ")} FCFA`;

export const TESTIMONIALS = [
  {
    quote:
      "J'ai commandé un kaba pour la dot de ma sœur : coupe parfaite, tissu magnifique et livraison en deux jours. Tout le monde m'a demandé l'adresse de LA DIVA !",
    name: "Mireille N.",
    city: "Douala",
    img: px(1820575, 200, 200),
  },
  {
    quote:
      "Un boubou brodé d'une qualité rare. Le service sur WhatsApp est rapide et attentionné, on se sent conseillée comme en boutique.",
    name: "Aïcha B.",
    city: "Yaoundé",
    img: px(1820559, 200, 200),
  },
  {
    quote:
      "Mon ensemble wax a fait sensation au mariage de ma cousine. Les finitions sont impeccables et la taille était exactement celle annoncée.",
    name: "Grâce T.",
    city: "Bafoussam",
    img: px(38528495, 200, 200),
  },
  {
    quote:
      "Je commande mes chaussures et mes robes de bureau chez LA DIVA depuis un an. Toujours élégant, toujours livré à l'heure.",
    name: "Sandrine E.",
    city: "Douala",
    img: px(7717254, 200, 200),
  },
  {
    quote:
      "Ma tenue de cérémonie sur mesure a été réalisée en une semaine. J'avais l'impression de porter une pièce de créateur.",
    name: "Fatou K.",
    city: "Kribi",
    img: px(6497112, 200, 200),
  },
  {
    quote:
      "Des prix justes pour une telle qualité, c'est rare. C'est devenu ma boutique préférée pour toutes les fêtes de fin d'année !",
    name: "Laure M.",
    city: "Limbé",
    img: px(9741840, 200, 200),
  },
];

export const LOOKBOOK = [
  { img: IMG.hero, title: "Boubou Soleil", type: "Mode africaine" },
  { img: IMG.kaba, title: "Kaba Ngondo", type: "Mode africaine" },
  { img: IMG.robes, title: "Chic urbain", type: "Prêt-à-porter" },
  { img: IMG.shoes, title: "Sandales dorées", type: "Chaussures" },
  { img: IMG.ceremony, title: "Émeraude", type: "Cérémonie" },
  { img: IMG.wax, title: "Ankara Sunset", type: "Wax & Ankara" },
  { img: IMG.robeNoire, title: "Noir absolu", type: "Prêt-à-porter" },
  { img: IMG.pagne, title: "Pagne indigo", type: "Mode africaine" },
  { img: IMG.boubou, title: "Bazin brodé", type: "Mode africaine" },
];

export const COLLECTIONS = [
  {
    title: "Kaba & Boubou",
    desc: "Des coupes élégantes, confectionnées dans de beaux tissus, pour mariages, fêtes et cérémonies.",
    img: IMG.boubou,
    thumb: IMG.kaba,
  },
  {
    title: "Wax & Ankara",
    desc: "Des imprimés vibrants et des coupes modernes : ensembles, jupes, tops et robes pour affirmer votre style au quotidien.",
    img: IMG.wax,
    thumb: IMG.pagne,
  },
  {
    title: "Chaussures",
    desc: "Sandales, escarpins, mules et babouches pour sublimer chaque tenue, du bureau à la cérémonie.",
    img: IMG.shoes,
    thumb: IMG.accessoires,
  },
  {
    title: "Prêt-à-porter",
    desc: "Robes, hauts, pantalons et vestes tendance pour une allure chic et confortable, chaque jour.",
    img: IMG.robes,
    thumb: IMG.robeNoire,
  },
];
