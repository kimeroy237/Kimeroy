import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type ElementType,
  type ReactNode,
} from "react";
import { cn } from "@/utils/cn";
import { waLink } from "@/data";
import { WhatsAppIcon } from "./Icons";

/* ---------- Navigation context (black strip page transition) ---------- */
export const NavCtx = createContext<(id: string) => void>(() => {});
export const useGoTo = () => useContext(NavCtx);

/* ---------- In-view hook ---------- */
export function useInView<T extends Element>(threshold = 0.18) {
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (!("IntersectionObserver" in window)) {
      setInView(true);
      return;
    }
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setInView(true);
          io.disconnect();
        }
      },
      { threshold, rootMargin: "0px 0px -8% 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);
  return [ref, inView] as const;
}

/* ---------- Reveal wrapper ---------- */
export function Reveal({
  children,
  className,
  delay = 0,
  as: Tag = "div",
  variant = "reveal",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: ElementType;
  variant?: "reveal" | "clip-reveal";
}) {
  const [ref, inView] = useInView<HTMLDivElement>();
  return (
    <Tag
      ref={ref}
      className={cn(variant, inView && "in", className)}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}

/* ---------- Masked headline (line-by-line slide in) ---------- */
export function MaskText({
  lines,
  className,
  as: Tag = "h2",
  delay = 0,
}: {
  lines: ReactNode[];
  className?: string;
  as?: ElementType;
  delay?: number;
}) {
  const [ref, inView] = useInView<HTMLHeadingElement>(0.3);
  return (
    <Tag ref={ref} className={cn(inView && "in", className)}>
      {lines.map((l, i) => (
        <span key={i} className="mask-line">
          <span style={{ transitionDelay: `${delay + i * 120}ms` }}>{l}</span>
        </span>
      ))}
    </Tag>
  );
}

/* ---------- Golden 4-point star ---------- */
export const Star4 = ({ className = "h-4 w-4 text-ochre" }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
    <path d="M12 0C12.7 6.4 17.6 11.3 24 12 17.6 12.7 12.7 17.6 12 24 11.3 17.6 6.4 12.7 0 12 6.4 11.3 11.3 6.4 12 0Z" />
  </svg>
);

export const Stars5 = ({ className = "h-4 w-4" }: { className?: string }) => (
  <span className="inline-flex gap-0.5 text-ochre" aria-label="5 étoiles sur 5">
    {Array.from({ length: 5 }).map((_, i) => (
      <svg key={i} viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
        <path d="m12 2 2.95 6.6 7.05.65-5.35 4.7 1.6 6.95L12 17.3l-6.25 3.6 1.6-6.95L2 9.25l7.05-.65L12 2Z" />
      </svg>
    ))}
  </span>
);

/* ---------- Beveled photo with slice line + parallax ---------- */
export function Bevel({
  src,
  alt,
  className,
  imgClassName,
  slice = true,
  sliceAt = "64%",
  sliceColor = "#F6F1E9",
  b = 26,
  parallax = 0,
  alt2 = false,
  eager = false,
  children,
}: {
  src: string;
  alt: string;
  className?: string;
  imgClassName?: string;
  slice?: boolean;
  sliceAt?: string;
  sliceColor?: string;
  b?: number;
  parallax?: number;
  alt2?: boolean;
  eager?: boolean;
  children?: ReactNode;
}) {
  return (
    <div
      className={cn("relative overflow-hidden bg-sand", alt2 ? "bevel-alt" : "bevel", className)}
      style={{ "--b": `${b}px` } as CSSProperties}
    >
      <img
        src={src}
        alt={alt}
        loading={eager ? "eager" : "lazy"}
        decoding="async"
        data-parallax={parallax || undefined}
        className={cn(
          "absolute left-0 w-full object-cover",
          parallax ? "-top-[8%] h-[116%]" : "top-0 h-full",
          imgClassName
        )}
      />
      {slice && (
        <span
          aria-hidden="true"
          className="pointer-events-none absolute inset-x-0 z-10 h-[2px]"
          style={{ top: sliceAt, background: sliceColor }}
        />
      )}
      {children}
    </div>
  );
}

/* ---------- Buttons ---------- */
type BtnProps = {
  children: ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: "outline" | "dark" | "light" | "ochre";
  className?: string;
  arrow?: boolean;
};

export function PillButton({ children, href, onClick, variant = "outline", className, arrow = true }: BtnProps) {
  const styles = {
    outline: "border border-ink/70 text-ink hover:bg-ink hover:text-ivory",
    dark: "border border-ink bg-ink text-ivory hover:bg-ochre hover:border-ochre",
    light: "border border-ivory/50 text-ivory hover:bg-ivory hover:text-ink",
    ochre: "border border-ochre bg-ochre text-white hover:bg-ink hover:border-ink",
  }[variant];
  const cls = cn(
    "group inline-flex h-12 items-center justify-center gap-3 rounded-full px-6 text-[12px] font-semibold uppercase tracking-[0.16em] transition-colors duration-300",
    styles,
    className
  );
  const inner = (
    <>
      <span>{children}</span>
      {arrow && <span className="inline-block transition-transform duration-300 group-hover:translate-x-1">→</span>}
    </>
  );
  if (href)
    return (
      <a href={href} className={cls} target={href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer">
        {inner}
      </a>
    );
  return (
    <button type="button" onClick={onClick} className={cls}>
      {inner}
    </button>
  );
}

export function WaButton({
  message,
  children = "Commander sur WhatsApp",
  className,
  size = "md",
}: {
  message?: string;
  children?: ReactNode;
  className?: string;
  size?: "sm" | "md" | "lg";
}) {
  const sizes = {
    sm: "h-11 px-4 text-[13px] gap-2",
    md: "h-12 px-6 text-[14px] gap-2.5",
    lg: "h-16 px-8 text-base sm:h-[72px] sm:px-10 sm:text-lg gap-3",
  }[size];
  return (
    <a
      href={waLink(message)}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        "group inline-flex items-center justify-center rounded-full bg-wa font-semibold text-white shadow-[0_8px_24px_-10px_rgba(37,211,102,.8)] transition-all duration-300 hover:bg-wa-dark hover:-translate-y-0.5",
        sizes,
        className
      )}
    >
      <WhatsAppIcon className={size === "lg" ? "h-6 w-6" : "h-[18px] w-[18px]"} />
      <span>{children}</span>
    </a>
  );
}

export function RoundButton({
  children,
  onClick,
  label,
  className,
  href,
}: {
  children: ReactNode;
  onClick?: () => void;
  label: string;
  className?: string;
  href?: string;
}) {
  const cls = cn(
    "inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-ink/25 transition-all duration-300 hover:border-ink hover:bg-ink hover:text-ivory",
    className
  );
  if (href)
    return (
      <a href={href} aria-label={label} className={cls} target="_blank" rel="noopener noreferrer">
        {children}
      </a>
    );
  return (
    <button type="button" aria-label={label} onClick={onClick} className={cls}>
      {children}
    </button>
  );
}

/* ---------- Section label ---------- */
export const Label = ({ children, className }: { children: ReactNode; className?: string }) => (
  <span className={cn("label inline-flex items-center gap-2", className)}>{children}</span>
);

/* ---------- Wax divider with black strip sweep ---------- */
export function SectionDivider({ className, light = false }: { className?: string; light?: boolean }) {
  const [ref, inView] = useInView<HTMLDivElement>(0.6);
  return (
    <div ref={ref} className={cn("relative mx-4 overflow-hidden sm:mx-8", inView && "in", className)} aria-hidden="true">
      <div className={cn("wax-strip", light && "light")} />
      <div className={cn("wipe-bar absolute inset-0", light ? "bg-ivory" : "bg-ink")} />
    </div>
  );
}
