import { useEffect, useState } from "react";
import { cn } from "@/utils/cn";
import { IMG, fcfa } from "@/data";
import { Bevel, Label, MaskText, PillButton, Reveal, Star4, useGoTo } from "@/components/ui";

const SLIDES = [
  { img: IMG.wax, title: "Ensemble Ankara Sunset", price: 25000, old: 31000 },
  { img: IMG.pagne, title: "Ensemble Pagne Indigo", price: 28000, old: 35000 },
  { img: IMG.ceremony, title: "Robe Cérémonie Émeraude", price: 48000, old: 60000 },
];

const OCCASIONS = ["Mariage", "Dot", "Baptême", "Anniversaire", "Bureau", "Soirée", "Fêtes"];

export default function Occasions() {
  const goTo = useGoTo();
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % SLIDES.length), 5000);
    return () => clearInterval(t);
  }, [i]);
  const s = SLIDES[i];

  return (
    <section id="occasions" className="relative px-4 py-16 sm:px-8 lg:py-24">
      <div className="grid gap-10 lg:grid-cols-12 lg:gap-8">
        {/* Left */}
        <div className="flex flex-col justify-between gap-10 lg:col-span-4">
          <div>
            <Label className="text-ink/60">//OCCASIONS</Label>
            <MaskText
              className="mt-5 text-[clamp(3rem,13vw,4.5rem)] font-semibold leading-[0.88] tracking-[-0.06em] lg:text-[clamp(3.5rem,6.4vw,7rem)]"
              lines={[
                <>Toutes —</>,
                <>
                  <span className="serif-i">vos</span>
                </>,
                <>occasions</>,
              ]}
            />
          </div>
          <Reveal className="hidden lg:block">
            <div className="flex items-end gap-4">
              <Bevel src={IMG.kaba} alt="Kaba wax" b={12} slice={false} className="h-28 w-24 shrink-0" />
              <p className="text-sm leading-relaxed text-ink/70">
                Mariages, dots, baptêmes ou journées au bureau : une tenue pensée pour chaque moment de votre vie.
              </p>
            </div>
          </Reveal>
        </div>

        {/* Center: big beveled slider */}
        <Reveal className="lg:col-span-5" variant="clip-reveal">
          <div className="relative">
            <div className="bevel relative aspect-[4/5] overflow-hidden bg-sand" style={{ ["--b" as string]: "40px" }}>
              {SLIDES.map((sl, k) => (
                <img
                  key={sl.img}
                  src={sl.img}
                  alt={sl.title}
                  loading="lazy"
                  className={cn(
                    "absolute inset-0 h-full w-full object-cover transition-all duration-[1200ms] ease-[cubic-bezier(.2,.7,.2,1)]",
                    k === i ? "scale-100 opacity-100" : "scale-110 opacity-0"
                  )}
                />
              ))}
              <span className="absolute inset-x-0 top-[68%] z-10 h-[2px] bg-ivory" />
              <div className="absolute bottom-5 left-5 right-5 z-10 flex items-end justify-between text-ivory">
                <div key={s.title} className="fade-up">
                  <p className="label text-ivory/80">N°0{i + 1}</p>
                  <p className="mt-1 text-xl font-semibold tracking-tight drop-shadow sm:text-2xl">{s.title}</p>
                </div>
              </div>
            </div>
            {/* promo badge */}
            <div className="absolute -right-2 -top-4 z-20 flex h-20 w-20 rotate-12 flex-col items-center justify-center rounded-full bg-terra text-white shadow-lg sm:-right-5 sm:h-24 sm:w-24">
              <span className="text-2xl font-bold tracking-tight sm:text-3xl">-20%</span>
              <span className="text-[9px] uppercase tracking-[0.2em]">Promo</span>
            </div>
            {/* dots */}
            <div className="mt-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                {SLIDES.map((_, k) => (
                  <button
                    key={k}
                    type="button"
                    aria-label={`Afficher la tenue ${k + 1}`}
                    onClick={() => setI(k)}
                    className={cn("h-2 rounded-full transition-all duration-500", k === i ? "w-8 bg-ink" : "w-2 bg-ink/25 hover:bg-ink/50")}
                  />
                ))}
              </div>
              <span className="label text-ink/50">
                0{i + 1} / 0{SLIDES.length}
              </span>
            </div>
          </div>
        </Reveal>

        {/* Right */}
        <div className="flex flex-col justify-between gap-8 lg:col-span-3">
          <Reveal delay={150}>
            <Star4 className="h-6 w-6 text-ochre" />
            <p className="mt-4 text-2xl font-medium leading-[1.15] tracking-[-0.03em] sm:text-[28px]">
              Là où l'élégance africaine rencontre <span className="serif-i text-terra">la mode d'aujourd'hui</span>
            </p>
            <div className="mt-6 flex items-baseline gap-3">
              <span className="label text-ink/50">À partir de</span>
            </div>
            <p className="mt-1 flex items-baseline gap-3">
              <span key={s.price} className="fade-up text-3xl font-semibold tracking-[-0.04em] text-ochre sm:text-4xl">{fcfa(s.price)}</span>
              <span className="text-sm text-ink/40 line-through">{fcfa(s.old)}</span>
            </p>
          </Reveal>

          <Reveal delay={250}>
            <div className="flex flex-wrap gap-2">
              {OCCASIONS.map((o) => (
                <span key={o} className="rounded-full border border-ink/15 px-3 py-1.5 text-xs font-medium text-ink/70">
                  {o}
                </span>
              ))}
            </div>
            <div className="mt-6 flex items-center gap-4">
              <Bevel src={IMG.ceremony} alt="Tenue de cérémonie" b={10} slice={false} className="h-20 w-16 shrink-0" />
              <PillButton onClick={() => goTo("produits")} className="flex-1">
                En savoir plus
              </PillButton>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
