import { WA_DISPLAY } from "@/data";
import { MaskText, Reveal, Star4, WaButton } from "@/components/ui";

export default function CtaBanner() {
  return (
    <section className="px-4 pb-16 sm:px-8 lg:pb-24">
      <Reveal variant="clip-reveal">
        <div className="relative overflow-hidden rounded-[28px] bg-ochre text-ink sm:rounded-[40px]">
          <div className="wax-strip" />
          <Star4 className="spin-slow absolute -right-10 -top-10 h-48 w-48 text-ink/10 sm:h-72 sm:w-72" />
          <Star4 className="absolute bottom-10 left-6 h-6 w-6 text-ivory" />
          <div className="relative grid gap-10 px-6 py-14 sm:px-12 sm:py-20 lg:grid-cols-12 lg:items-end lg:px-16">
            <div className="lg:col-span-8">
              <p className="label text-ink/70">//UNE QUESTION ?</p>
              <MaskText
                className="mt-5 text-[clamp(2.4rem,9.5vw,4rem)] font-semibold leading-[0.92] tracking-[-0.055em] lg:text-[clamp(3.2rem,5.6vw,6rem)]"
                lines={[
                  <>Une envie, une question,</>,
                  <>une commande ?</>,
                  <>
                    <span className="serif-i text-ivory">Écrivez-nous</span>
                  </>,
                ]}
              />
            </div>
            <div className="flex flex-col items-start gap-4 lg:col-span-4 lg:items-end lg:text-right">
              <WaButton size="lg" message="Bonjour LA DIVA, j'ai une question / je souhaite passer une commande">
                Discuter sur WhatsApp
              </WaButton>
              <p className="text-sm font-medium text-ink/75">
                {WA_DISPLAY} · Réponse rapide, 7j/7
              </p>
            </div>
          </div>
          <div className="wax-strip" />
        </div>
      </Reveal>
    </section>
  );
}
