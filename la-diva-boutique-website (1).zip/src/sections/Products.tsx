import { useState } from "react";
import { cn } from "@/utils/cn";
import { PRODUCTS, fcfa, type Product } from "@/data";
import { Bevel, Label, MaskText, Reveal, WaButton } from "@/components/ui";

const FILTERS: { key: "all" | Product["group"]; label: string }[] = [
  { key: "all", label: "Tout" },
  { key: "africain", label: "Mode africaine" },
  { key: "pret", label: "Prêt-à-porter" },
  { key: "chaussures", label: "Chaussures" },
];

function Card({ p, i }: { p: Product; i: number }) {
  return (
    <article className="group flex h-full flex-col">
      <div className="relative">
        <Bevel
          src={p.img}
          alt={p.name}
          b={28}
          sliceAt={i % 2 ? "30%" : "70%"}
          className="aspect-[4/5] w-full"
          imgClassName="transition-transform duration-[1200ms] ease-[cubic-bezier(.2,.7,.2,1)] group-hover:scale-[1.06]"
        />
        {p.badge && (
          <span
            className={cn(
              "absolute left-4 top-4 z-20 rounded-full px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.18em]",
              p.badge.startsWith("-") ? "bg-terra text-white" : "bg-ivory text-ink"
            )}
          >
            {p.badge}
          </span>
        )}
        <span className="label absolute right-5 top-5 z-20 text-ivory drop-shadow">N°{String(i + 1).padStart(2, "0")}</span>
      </div>
      <div className="flex flex-1 flex-col pt-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="label text-ink/50">{p.category}</p>
            <h3 className="mt-1.5 text-xl font-semibold leading-tight tracking-[-0.03em] sm:text-2xl">{p.name}</h3>
          </div>
          <div className="text-right">
            <p className="whitespace-nowrap text-lg font-semibold tracking-tight text-ochre">{fcfa(p.price)}</p>
            {p.oldPrice && <p className="text-xs text-ink/40 line-through">{fcfa(p.oldPrice)}</p>}
          </div>
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-1.5">
          <span className="mr-1 text-[11px] uppercase tracking-[0.16em] text-ink/50">Tailles</span>
          {p.sizes.map((s) => (
            <span key={s} className="rounded-full border border-ink/15 px-2.5 py-1 text-[11px] font-medium">
              {s}
            </span>
          ))}
        </div>
        <WaButton
          size="sm"
          className="mt-5 w-full"
          message={`Bonjour LA DIVA, je suis intéressée par : ${p.name} (${fcfa(p.price)}). Est-il disponible ?`}
        />
      </div>
    </article>
  );
}

export default function Products() {
  const [f, setF] = useState<(typeof FILTERS)[number]["key"]>("all");
  const list = PRODUCTS.filter((p) => f === "all" || p.group === f);

  return (
    <section id="produits" className="relative px-4 py-16 sm:px-8 lg:py-24">
      <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <Label className="text-ink/60">//BOUTIQUE</Label>
          <MaskText
            className="mt-4 text-[clamp(2.8rem,11vw,4.5rem)] font-semibold leading-[0.9] tracking-[-0.06em] lg:text-[clamp(3.5rem,6vw,6.5rem)]"
            lines={[
              <>Pièces —</>,
              <>
                <span className="serif-i text-terra">à la</span> une
              </>,
            ]}
          />
        </div>
        <Reveal className="flex flex-col gap-5 lg:items-end">
          <p className="max-w-sm text-[15px] leading-relaxed text-ink/70 lg:text-right">
            Choisissez votre pièce, cliquez sur « Commander sur WhatsApp » : nous confirmons la taille, la disponibilité et la livraison.
          </p>
          <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 sm:mx-0 sm:px-0">
            {FILTERS.map((x) => (
              <button
                key={x.key}
                type="button"
                onClick={() => setF(x.key)}
                className={cn(
                  "h-10 shrink-0 rounded-full border px-4 text-[12px] font-semibold uppercase tracking-[0.12em] transition-colors",
                  f === x.key ? "border-ink bg-ink text-ivory" : "border-ink/20 hover:border-ink"
                )}
              >
                {x.label}
              </button>
            ))}
          </div>
        </Reveal>
      </div>

      {/* Mobile: horizontal snap / Desktop: grid */}
      <div className="no-scrollbar -mx-4 mt-10 flex snap-x snap-mandatory gap-5 overflow-x-auto px-4 pb-2 sm:mx-0 sm:grid sm:grid-cols-2 sm:gap-x-6 sm:gap-y-12 sm:overflow-visible sm:px-0 lg:mt-14 lg:grid-cols-3">
        {list.map((p) => (
          <Reveal key={p.name} delay={(PRODUCTS.indexOf(p) % 3) * 100} className="w-[82%] shrink-0 snap-center sm:w-auto">
            <Card p={p} i={PRODUCTS.indexOf(p)} />
          </Reveal>
        ))}
      </div>
      <p className="label mt-4 text-center text-ink/40 sm:hidden">← Glissez pour voir plus →</p>
    </section>
  );
}
