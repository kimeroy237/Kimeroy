import { useEffect, useState } from "react";
import { cn } from "@/utils/cn";
import { AVATARS, IMG } from "@/data";
import { Bevel, Label, PillButton, Star4, useGoTo, WaButton } from "@/components/ui";

function Line({ children, delay, on, className }: { children: React.ReactNode; delay: number; on: boolean; className?: string }) {
  return (
    <span className={cn("mask-line", on && "in", className)}>
      <span style={{ transitionDelay: `${delay}ms` }}>{children}</span>
    </span>
  );
}

function RotatingBadge() {
  return (
    <div className="relative h-24 w-24 sm:h-28 sm:w-28">
      <svg viewBox="0 0 100 100" className="spin-slow h-full w-full">
        <defs>
          <path id="circ" d="M50,50 m-38,0 a38,38 0 1,1 76,0 a38,38 0 1,1 -76,0" />
        </defs>
        <circle cx="50" cy="50" r="49" fill="#111" />
        <text fill="#F6F1E9" fontSize="10.5" letterSpacing="3.2" fontWeight="600">
          <textPath href="#circ">COLLECTION 2026 • LA DIVA • </textPath>
        </text>
      </svg>
      <Star4 className="absolute left-1/2 top-1/2 h-7 w-7 -translate-x-1/2 -translate-y-1/2 text-ochre" />
    </div>
  );
}

export default function Hero() {
  const goTo = useGoTo();
  const [on, setOn] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setOn(true), 150);
    return () => clearTimeout(t);
  }, []);

  const big = "text-[clamp(3.6rem,15vw,5.5rem)] sm:text-[clamp(4.5rem,12vw,7rem)] lg:text-[clamp(5rem,9.6vw,10.5rem)]";

  return (
    <section id="accueil" className="relative px-4 pb-14 pt-4 sm:px-8 lg:pb-20">
      {/* top labels */}
      <div className="flex items-start justify-between gap-4">
        <Label className={cn("text-ink/60 transition-all duration-700", on ? "opacity-100" : "opacity-0")}>/ Nouvelle collection 2026</Label>
        <Label className={cn("transition-all delay-200 duration-700", on ? "opacity-100" : "opacity-0")}>
          <Star4 className="h-3 w-3 text-ochre" /> //STYLE &amp; TRADITION
        </Label>
      </div>

      <div className="relative mt-6 lg:mt-8 lg:min-h-[44vw] xl:min-h-[640px]">
        <h1 className={cn("relative font-semibold leading-[0.86] tracking-[-0.065em]", big)}>
          {/* Left part */}
          <span className="relative z-0 block">
            <Line on={on} delay={100}>l'élégance</Line>
            <Line on={on} delay={220}>
              <span className="text-ochre">—</span> <span className="serif-i">qui</span>
            </Line>
          </span>

          {/* Model (mobile: in flow, desktop: absolutely centered) */}
          <span
            className={cn(
              "relative z-10 mx-auto -mt-[6vw] block w-[74%] max-w-[360px] transition-all duration-[1400ms] ease-[cubic-bezier(.2,.7,.2,1)]",
              "sm:w-[52%] lg:absolute lg:left-1/2 lg:top-[-1.5vw] lg:mt-0 lg:w-[27vw] lg:max-w-[420px] lg:-translate-x-1/2",
              on ? "opacity-100 [clip-path:inset(0_0_0_0)]" : "opacity-0 [clip-path:inset(100%_0_0_0)]"
            )}
          >
            <Bevel src={IMG.hero} alt="Mannequin en boubou wax moderne — LA DIVA" b={34} parallax={30} eager sliceAt="58%" className="aspect-[3/4.2] w-full" imgClassName="object-top" />
            <span className="absolute -bottom-6 -left-8 z-20 hidden sm:block lg:-left-12">
              <RotatingBadge />
            </span>
            <Star4 className="absolute -right-4 top-10 z-20 h-8 w-8 text-ochre sm:-right-6" />
          </span>

          {/* Right part */}
          <span className="relative z-20 -mt-[11vw] block text-right sm:-mt-[9vw] lg:absolute lg:right-0 lg:top-0 lg:mt-0">
            <Line on={on} delay={340}>vit</Line>
            <Line on={on} delay={460}>
              <span className="text-ochre">—</span> en <span className="serif-i text-terra">toi</span>
            </Line>
          </span>
        </h1>

        {/* bottom content */}
        <div className="relative z-20 mt-10 grid gap-8 lg:mt-[4vw] lg:grid-cols-[1fr_29vw_1fr] lg:items-end xl:grid-cols-[1fr_440px_1fr]">
          <div className={cn("max-w-sm transition-all delay-500 duration-1000", on ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0")}>
            <p className="text-[15px] leading-relaxed text-ink/75 sm:text-base">
              Vêtements, chaussures et mode africaine : des pièces choisies avec soin pour toutes vos occasions.
            </p>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap lg:flex-col xl:flex-row">
              <WaButton message="Bonjour LA DIVA, je souhaite passer une commande" />
              <PillButton onClick={() => goTo("produits")}>Voir la collection</PillButton>
            </div>
          </div>

          <div className="hidden lg:block" />

          <div className={cn("flex items-center justify-between gap-4 lg:flex-col lg:items-end lg:text-right transition-all delay-700 duration-1000", on ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0")}>
            <div className="flex items-center">
              {AVATARS.map((a, i) => (
                <img key={a} src={a} alt="Cliente LA DIVA" loading="lazy" className="-ml-3 h-11 w-11 rounded-full border-2 border-ivory object-cover first:ml-0 sm:h-12 sm:w-12" style={{ zIndex: 10 - i }} />
              ))}
              <button
                type="button"
                onClick={() => goTo("temoignages")}
                aria-label="Voir les avis clientes"
                className="-ml-3 flex h-11 w-11 items-center justify-center rounded-full border-2 border-ivory bg-ochre text-xl font-light text-white transition hover:rotate-90 hover:bg-terra sm:h-12 sm:w-12"
              >
                +
              </button>
            </div>
            <div>
              <p className="text-4xl font-semibold tracking-[-0.05em] sm:text-5xl">500+</p>
              <p className="label mt-1 text-ink/60">Clientes satisfaites</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
