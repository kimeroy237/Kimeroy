import { useEffect, useState } from "react";
import { cn } from "@/utils/cn";
import { NAV, PRODUCTS, fcfa, waLink, WA_DISPLAY } from "@/data";
import { RoundButton, Star4, useGoTo, WaButton } from "@/components/ui";
import { BagIcon, CloseIcon, SearchIcon, WhatsAppIcon, ArrowUpRight } from "@/components/Icons";

export default function Header() {
  const goTo = useGoTo();
  const [menu, setMenu] = useState(false);
  const [search, setSearch] = useState(false);
  const [q, setQ] = useState("");
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menu || search ? "hidden" : "";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMenu(false);
        setSearch(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menu, search]);

  const results = PRODUCTS.filter((p) =>
    (p.name + " " + p.category).toLowerCase().includes(q.trim().toLowerCase())
  );

  return (
    <>
      <header
        className={cn(
          "sticky top-0 z-40 transition-all duration-500",
          scrolled ? "bg-ivory/85 shadow-[0_1px_0_rgba(17,17,17,.08)] backdrop-blur-md" : "bg-transparent"
        )}
      >
        <div className="relative flex h-[72px] items-center justify-between px-4 sm:h-20 sm:px-8">
          <button
            type="button"
            aria-label="Ouvrir le menu"
            onClick={() => setMenu(true)}
            className="group flex h-11 w-11 flex-col items-center justify-center gap-[5px] rounded-full border border-ink/25 transition hover:bg-ink"
          >
            <span className="h-px w-[18px] bg-ink transition group-hover:bg-ivory" />
            <span className="h-px w-3 -translate-x-[3px] bg-ink transition-all group-hover:w-[18px] group-hover:translate-x-0 group-hover:bg-ivory" />
          </button>

          <a
            href="#accueil"
            onClick={(e) => {
              e.preventDefault();
              goTo("accueil");
            }}
            className="absolute left-1/2 flex -translate-x-1/2 items-center gap-1.5 text-[22px] font-extrabold tracking-[-0.04em] sm:text-[28px]"
          >
            LA <Star4 className="h-3 w-3 text-ochre sm:h-3.5 sm:w-3.5" /> DIVA
          </a>

          <div className="flex items-center gap-1.5 sm:gap-2">
            <RoundButton label="Rechercher" onClick={() => setSearch(true)} className="hidden h-10 w-10 min-[380px]:inline-flex sm:h-11 sm:w-11">
              <SearchIcon />
            </RoundButton>
            <button
              type="button"
              aria-label="Panier"
              onClick={() => goTo("produits")}
              className="relative hidden h-11 w-11 items-center justify-center rounded-full border border-ink/25 transition hover:bg-ink hover:text-ivory sm:inline-flex"
            >
              <BagIcon />
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-terra px-1 text-[9px] font-bold text-white">
                {PRODUCTS.length}
              </span>
            </button>
            <a
              href={waLink("Bonjour LA DIVA, je souhaite avoir des informations sur vos articles")}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Écrire sur WhatsApp"
              className="inline-flex h-10 items-center gap-2 rounded-full bg-wa px-3 text-[13px] font-semibold text-white transition hover:bg-wa-dark sm:h-11 sm:px-5"
            >
              <WhatsAppIcon className="h-[18px] w-[18px]" />
              <span className="hidden md:inline">WhatsApp</span>
            </a>
          </div>
        </div>
      </header>

      {/* ---------- Full screen menu ---------- */}
      <div
        className={cn(
          "fixed inset-0 z-[60] flex flex-col bg-ink text-ivory transition-[clip-path] duration-700 ease-[cubic-bezier(.77,0,.18,1)]",
          menu ? "[clip-path:inset(0_0_0_0)]" : "pointer-events-none [clip-path:inset(0_0_100%_0)]"
        )}
        aria-hidden={!menu}
      >
        <div className="flex h-[72px] items-center justify-between px-4 sm:h-20 sm:px-8">
          <span className="label text-ivory/50">//MENU</span>
          <span className="text-2xl font-extrabold tracking-[-0.04em]">LA DIVA</span>
          <button
            type="button"
            aria-label="Fermer le menu"
            onClick={() => setMenu(false)}
            className="flex h-11 w-11 items-center justify-center rounded-full border border-ivory/30 transition hover:bg-ivory hover:text-ink"
          >
            <CloseIcon />
          </button>
        </div>
        <nav className="flex flex-1 flex-col justify-center gap-1 overflow-y-auto px-6 sm:px-16">
          {NAV.map((n, i) => (
            <a
              key={n.id}
              href={`#${n.id}`}
              onClick={(e) => {
                e.preventDefault();
                setMenu(false);
                goTo(n.id);
              }}
              className="group flex items-baseline gap-4 border-b border-ivory/10 py-2 text-[clamp(2rem,7vw,4.5rem)] font-semibold leading-[1.05] tracking-[-0.04em] transition-colors hover:text-ochre"
              style={{
                transform: menu ? "none" : "translateY(30px)",
                opacity: menu ? 1 : 0,
                transition: `all .7s cubic-bezier(.2,.7,.2,1) ${menu ? 200 + i * 50 : 0}ms`,
              }}
            >
              <span className="label text-ochre">[0{i + 1}]</span>
              <span className="transition-transform duration-500 group-hover:translate-x-3">{n.label}</span>
              {i % 3 === 1 && <span className="serif-i text-[0.6em] text-ivory/40 group-hover:text-ochre">✦</span>}
            </a>
          ))}
        </nav>
        <div className="flex flex-col gap-4 px-6 pb-8 pt-6 sm:flex-row sm:items-center sm:justify-between sm:px-16">
          <p className="text-sm text-ivory/60">Appel / WhatsApp : {WA_DISPLAY}</p>
          <WaButton message="Bonjour LA DIVA, je souhaite passer une commande" />
        </div>
      </div>

      {/* ---------- Search overlay ---------- */}
      <div
        className={cn(
          "fixed inset-0 z-[60] transition-opacity duration-500",
          search ? "opacity-100" : "pointer-events-none opacity-0"
        )}
        aria-hidden={!search}
      >
        <div className="absolute inset-0 bg-ink/50 backdrop-blur-sm" onClick={() => setSearch(false)} />
        <div
          className={cn(
            "relative mx-auto mt-4 w-[calc(100%-2rem)] max-w-2xl rounded-[28px] bg-ivory p-5 shadow-2xl transition-transform duration-500 sm:mt-16 sm:p-8",
            search ? "translate-y-0" : "-translate-y-8"
          )}
        >
          <div className="flex items-center justify-between">
            <span className="label">[Rechercher]</span>
            <button type="button" aria-label="Fermer" onClick={() => setSearch(false)} className="flex h-10 w-10 items-center justify-center rounded-full border border-ink/20 hover:bg-ink hover:text-ivory">
              <CloseIcon />
            </button>
          </div>
          <div className="mt-4 flex items-center gap-3 border-b border-ink pb-3">
            <SearchIcon className="h-5 w-5" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Kaba, boubou, sandales…"
              className="w-full bg-transparent text-2xl font-medium tracking-tight outline-none placeholder:text-ink/30 sm:text-3xl"
              autoFocus={search}
            />
          </div>
          <ul className="no-scrollbar mt-4 max-h-[55vh] divide-y divide-ink/10 overflow-y-auto">
            {results.length === 0 && <li className="py-6 text-sm text-ink/60">Aucun résultat… écrivez-nous sur WhatsApp, nous avons sûrement ce qu'il vous faut !</li>}
            {results.map((p) => (
              <li key={p.name}>
                <a
                  href={waLink(`Bonjour LA DIVA, je suis intéressée par : ${p.name}`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center gap-4 py-3"
                >
                  <img src={p.img} alt={p.name} loading="lazy" className="bevel h-16 w-14 object-cover" style={{ ["--b" as string]: "8px" }} />
                  <div className="flex-1">
                    <p className="font-semibold tracking-tight">{p.name}</p>
                    <p className="text-xs text-ink/50">{p.category}</p>
                  </div>
                  <span className="text-sm font-semibold text-ochre">{fcfa(p.price)}</span>
                  <ArrowUpRight className="h-4 w-4 transition group-hover:rotate-45" />
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </>
  );
}
