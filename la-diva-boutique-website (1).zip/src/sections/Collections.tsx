import { useState } from "react";
import { cn } from "@/utils/cn";
import { COLLECTIONS } from "@/data";
import { Bevel, Label, MaskText, PillButton, Reveal, Star4 } from "@/components/ui";
import { ArrowUpRight } from "@/components/Icons";
import { waLink } from "@/data";

export default function Collections() {
  const [open, setOpen] = useState<number | null>(0);
  const shown = open ?? 0;

  return (
    <section id="collections" className="relative px-4 py-16 sm:px-8 lg:py-24">
      <div className="grid gap-10 lg:grid-cols-12 lg:gap-12">
        {/* Left photo */}
        <Reveal className="lg:col-span-5">
          <div className="lg:sticky lg:top-28">
            <div className="bevel relative aspect-[4/3] overflow-hidden bg-sand sm:aspect-[4/5]" style={{ ["--b" as string]: "38px" }}>
              {COLLECTIONS.map((c, k) => (
                <img
                  key={c.title}
                  src={c.img}
                  alt={c.title}
                  loading="lazy"
                  className={cn(
                    "absolute inset-0 h-full w-full object-cover transition-all duration-[1000ms] ease-[cubic-bezier(.2,.7,.2,1)]",
                    k === shown ? "scale-100 opacity-100" : "scale-110 opacity-0"
                  )}
                />
              ))}
              <span className="absolute inset-x-0 top-[38%] z-10 h-[2px] bg-ivory" />
              <div className="absolute inset-x-0 bottom-0 z-10 bg-gradient-to-t from-ink/80 to-transparent p-6 pt-24 text-ivory">
                <Star4 className="h-5 w-5 text-ochre" />
                <p className="mt-3 text-[clamp(1.8rem,6vw,2.75rem)] font-semibold leading-[0.95] tracking-[-0.05em]">
                  Faites partie de <span className="serif-i text-ochre">notre histoire.</span>
                </p>
              </div>
            </div>
          </div>
        </Reveal>

        {/* Accordion */}
        <div className="lg:col-span-7">
          <Label>[COLLECTIONS]</Label>
          <MaskText
            className="mb-8 mt-4 text-[clamp(2.4rem,9vw,3.5rem)] font-semibold leading-[0.92] tracking-[-0.055em] lg:text-[clamp(3rem,4.2vw,4.5rem)]"
            lines={[
              <>Des collections</>,
              <>
                pour <span className="serif-i text-terra">chaque femme</span>
              </>,
            ]}
          />
          <ul className="border-t border-ink/15">
            {COLLECTIONS.map((c, k) => {
              const on = open === k;
              return (
                <li key={c.title} className="border-b border-ink/15">
                  <button
                    type="button"
                    aria-expanded={on}
                    onClick={() => setOpen(on ? null : k)}
                    className="group flex w-full items-center gap-4 py-5 text-left sm:py-6"
                  >
                    <span className={cn("label w-10 shrink-0 transition-colors", on ? "text-ochre" : "text-ink/40")}>0{k + 1}</span>
                    <span
                      className={cn(
                        "flex-1 text-[clamp(1.7rem,6.5vw,2.4rem)] font-semibold leading-none tracking-[-0.045em] transition-colors duration-500 lg:text-[clamp(2rem,3.2vw,3.2rem)]",
                        on ? "text-ink" : "text-ink/45 group-hover:text-ink"
                      )}
                    >
                      {c.title}
                    </span>
                    <span
                      className={cn(
                        "flex h-12 w-12 shrink-0 items-center justify-center rounded-full border transition-all duration-500 sm:h-14 sm:w-14",
                        on ? "rotate-90 border-ink bg-ink text-ivory" : "border-ink/25 group-hover:border-ink"
                      )}
                    >
                      <ArrowUpRight className="h-5 w-5" />
                    </span>
                  </button>
                  <div className={cn("grid transition-[grid-template-rows] duration-700 ease-[cubic-bezier(.2,.7,.2,1)]", on ? "grid-rows-[1fr]" : "grid-rows-[0fr]")}>
                    <div className="overflow-hidden">
                      <div
                        className={cn(
                          "flex flex-col gap-5 pb-7 pl-14 transition-all duration-700 sm:flex-row sm:items-end sm:justify-between",
                          on ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
                        )}
                      >
                        <div className="max-w-md">
                          <p className="text-[15px] leading-relaxed text-ink/70 sm:text-base">{c.desc}</p>
                          <PillButton
                            href={waLink(`Bonjour LA DIVA, je souhaite commander dans la collection « ${c.title} »`)}
                            variant="dark"
                            className="mt-5"
                          >
                            Commander
                          </PillButton>
                        </div>
                        <Bevel src={c.thumb} alt={c.title} b={14} slice={false} className="h-32 w-24 shrink-0 sm:h-36 sm:w-28" />
                      </div>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </section>
  );
}
