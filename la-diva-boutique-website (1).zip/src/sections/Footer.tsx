import { useState, type FormEvent } from "react";
import { NAV, WA_DISPLAY, WA_NUMBER, waLink } from "@/data";
import { Label, Star4, useGoTo, WaButton } from "@/components/ui";
import { ArrowRight, ClockIcon, FacebookIcon, InstagramIcon, PhoneIcon, PinIcon, TikTokIcon, WhatsAppIcon } from "@/components/Icons";

const SOCIALS = [
  { label: "Facebook", href: "https://facebook.com/", Icon: FacebookIcon },
  { label: "Instagram", href: "https://instagram.com/", Icon: InstagramIcon },
  { label: "TikTok", href: "https://tiktok.com/", Icon: TikTokIcon },
  { label: "WhatsApp", href: waLink(), Icon: WhatsAppIcon },
];

export default function Footer() {
  const goTo = useGoTo();
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) return;
    setDone(true);
    setEmail("");
  };

  const link = (id: string, label: string) => (
    <a
      href={`#${id}`}
      onClick={(e) => {
        e.preventDefault();
        goTo(id);
      }}
      className="text-ivory/70 transition hover:text-ochre"
    >
      {label}
    </a>
  );

  return (
    <footer id="contact" className="relative overflow-hidden bg-ink px-4 pb-8 pt-16 text-ivory sm:px-8 lg:pt-24">
      <div className="grid gap-12 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <Label className="text-ochre">
            <Star4 className="h-3 w-3 text-ochre" /> Contactez-nous
          </Label>
          <h2 className="mt-5 text-[clamp(2.4rem,9vw,4rem)] font-semibold leading-[0.92] tracking-[-0.055em] lg:text-[clamp(3rem,5vw,5.5rem)]">
            LA DIVA, mode &amp; <span className="serif-i text-ochre">élégance africaine</span>
          </h2>
          <div className="mt-8">
            <WaButton message="Bonjour LA DIVA, je souhaite passer une commande" />
          </div>
        </div>

        <div className="lg:col-span-5">
          <p className="label text-ivory/50">Newsletter · nouveautés &amp; promos</p>
          <form onSubmit={submit} className="mt-4 flex items-center gap-3 border-b border-ivory/30 pb-3 focus-within:border-ochre">
            <input
              type="email"
              required
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setDone(false);
              }}
              placeholder="Votre email"
              aria-label="Votre email"
              className="w-full bg-transparent text-xl outline-none placeholder:text-ivory/40 sm:text-2xl"
            />
            <button type="submit" aria-label="S'inscrire" className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-ochre text-white transition hover:bg-ivory hover:text-ink">
              <ArrowRight className="h-5 w-5" />
            </button>
          </form>
          <p className="mt-3 h-5 text-sm text-ochre">{done ? "Merci ! Vous recevrez bientôt nos nouveautés." : ""}</p>
          <div className="mt-6 flex gap-3">
            {SOCIALS.map(({ label, href, Icon }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="flex h-12 w-12 items-center justify-center rounded-full border border-ivory/25 transition hover:-translate-y-1 hover:border-ochre hover:bg-ochre"
              >
                <Icon className="h-5 w-5" />
              </a>
            ))}
          </div>
        </div>
      </div>

      <div className="wax-strip light mt-14 opacity-80" aria-hidden="true" />

      <div className="mt-12 grid grid-cols-2 gap-10 sm:grid-cols-3 lg:grid-cols-6">
        <div className="col-span-2 sm:col-span-1 lg:col-span-1">
          <p className="label flex items-center gap-2 text-ivory/50">
            <PinIcon /> Adresse
          </p>
          <p className="mt-3 text-sm leading-relaxed text-ivory/80">
            Boutique LA DIVA
            <br />
            [Adresse à compléter]
            <br />
            Douala, Cameroun
          </p>
        </div>
        <div className="col-span-2 sm:col-span-1 lg:col-span-1">
          <p className="label flex items-center gap-2 text-ivory/50">
            <PhoneIcon /> Appel / WhatsApp
          </p>
          <a href={`tel:+${WA_NUMBER}`} className="mt-3 block text-sm text-ivory/80 hover:text-ochre">
            {WA_DISPLAY}
          </a>
          <a href={waLink()} target="_blank" rel="noopener noreferrer" className="mt-1 inline-flex items-center gap-1.5 text-sm text-wa hover:underline">
            <WhatsAppIcon className="h-4 w-4" /> Écrire sur WhatsApp
          </a>
        </div>
        <div className="col-span-2 sm:col-span-1 lg:col-span-1">
          <p className="label flex items-center gap-2 text-ivory/50">
            <ClockIcon /> Horaires
          </p>
          <p className="mt-3 text-sm text-ivory/80">
            Lun - Sam
            <br />
            08h00 - 20h00
          </p>
        </div>

        <div>
          <p className="label text-ivory/50">Menu</p>
          <ul className="mt-3 space-y-2 text-sm">
            {NAV.slice(0, 5).map((n) => (
              <li key={n.id}>{link(n.id, n.label)}</li>
            ))}
          </ul>
        </div>
        <div>
          <p className="label text-ivory/50">Boutique</p>
          <ul className="mt-3 space-y-2 text-sm">
            {["Kaba", "Boubou", "Wax & Ankara", "Chaussures", "Prêt-à-porter"].map((c) => (
              <li key={c}>{link("categories", c)}</li>
            ))}
          </ul>
        </div>
        <div>
          <p className="label text-ivory/50">Infos</p>
          <ul className="mt-3 space-y-2 text-sm">
            <li>
              <a href={waLink("Bonjour LA DIVA, quelles sont vos conditions de livraison ?")} target="_blank" rel="noopener noreferrer" className="text-ivory/70 transition hover:text-ochre">
                Livraison
              </a>
            </li>
            <li>
              <a href={waLink("Bonjour LA DIVA, je souhaite des informations sur les retours / échanges")} target="_blank" rel="noopener noreferrer" className="text-ivory/70 transition hover:text-ochre">
                Retours
              </a>
            </li>
            <li>{link("contact", "Contact")}</li>
          </ul>
        </div>
      </div>

      <p aria-hidden="true" className="pointer-events-none mt-14 select-none whitespace-nowrap text-center text-[23vw] font-extrabold leading-[0.8] tracking-[-0.07em] text-ivory/[0.06]">
        LA DIVA
      </p>

      <div className="mt-6 flex flex-col gap-2 border-t border-ivory/10 pt-6 text-xs text-ivory/50 sm:flex-row sm:items-center sm:justify-between">
        <p>© 2026 LA DIVA — Tous droits réservés.</p>
        <p className="flex items-center gap-2">
          Mode &amp; élégance africaine <Star4 className="h-3 w-3 text-ochre" /> Fait avec amour au Cameroun
        </p>
      </div>
    </footer>
  );
}
