import { useEffect, useState } from "react";
import { TESTIMONIALS } from "@/data";
import { Label, MaskText, Reveal, RoundButton, Stars5 } from "@/components/ui";
import { ArrowLeft, ArrowRight } from "@/components/Icons";

export default function Testimonials() {
  const [i, setI] = useState(0);
  const n = TESTIMONIALS.length;
  const t = TESTIMONIALS[i];
  const prev = () => setI((v) => (v - 1 + n) % n);
  const next = () => setI((v) => (v + 1) % n);

  useEffect(() => {
    const id = setInterval(next, 7000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i]);

  return (
    <section id="temoignages" className="relative px-4 py-16 sm:px-8 lg:py-24">
      <div className="grid gap-10 lg:grid-cols-12 lg:gap-12">
        <div className="flex flex-col justify-between gap-8 lg:col-span-4">
          <div>
            <Label>[Témoignages]</Label>
            <MaskText
              className="mt-4 text-[clamp(2.6rem,10vw,4rem)] font-semibold leading-[0.9] tracking-[-0.055em] lg:text-[clamp(3rem,4.6vw,5rem)]"
              lines={[<>Ce que disent</>, <span className="serif-i text-ochre">nos clientes</span>]}
            />
          </div>
          <Reveal className="flex flex-wrap items-center justify-between gap-6 lg:flex-col lg:items-start">
            <div>
              <Stars5 className="h-5 w-5" />
              <p className="mt-2 text-sm">
                <span className="text-2xl font-semibold tracking-tight">5.0</span>{" "}
                <span className="text-ink/60">(49 avis)</span>
              </p>
            </div>
            <div className="flex gap-2">
              <RoundButton label="Témoignage précédent" onClick={prev} className="h-14 w-14">
                <ArrowLeft className="h-5 w-5" />
              </RoundButton>
              <RoundButton label="Témoignage suivant" onClick={next} className="h-14 w-14 border-ink bg-ink text-ivory hover:border-ochre hover:bg-ochre">
                <ArrowRight className="h-5 w-5" />
              </RoundButton>
            </div>
          </Reveal>
        </div>

        <Reveal className="relative lg:col-span-8" delay={100}>
          <div className="flex items-start justify-between border-b border-ink/15 pb-5">
            <span className="serif-i text-7xl leading-[0.6] text-ochre sm:text-8xl">“</span>
            <p className="text-sm font-medium tracking-wide">
              <span className="text-3xl font-semibold tracking-[-0.04em] sm:text-4xl">{String(i + 1).padStart(2, "0")}</span>
              <span className="text-ink/40">/{n}</span>
            </p>
          </div>

          <blockquote key={i} className="fade-up mt-8 min-h-[11rem] text-[clamp(1.5rem,5.4vw,2.2rem)] font-medium leading-[1.15] tracking-[-0.035em] sm:min-h-[12rem] lg:text-[clamp(1.9rem,2.9vw,3rem)]">
            {t.quote}
          </blockquote>

          <div key={`p-${i}`} className="fade-up mt-8 flex items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <img src={t.img} alt={t.name} loading="lazy" className="h-14 w-14 rounded-full object-cover ring-2 ring-ochre ring-offset-2 ring-offset-ivory sm:h-16 sm:w-16" />
              <div>
                <p className="text-lg font-semibold tracking-tight">{t.name}</p>
                <p className="label text-ink/50">Cliente · {t.city}</p>
              </div>
            </div>
            <Stars5 className="h-4 w-4" />
          </div>

          <div className="mt-8 flex gap-1.5">
            {TESTIMONIALS.map((_, k) => (
              <button
                key={k}
                type="button"
                aria-label={`Témoignage ${k + 1}`}
                onClick={() => setI(k)}
                className="h-1 flex-1 overflow-hidden rounded-full bg-ink/10"
              >
                <span className={`block h-full bg-ink transition-all duration-700 ${k <= i ? "w-full" : "w-0"}`} />
              </button>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
