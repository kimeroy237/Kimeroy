import { useState } from "react";
import { cn } from "@/utils/cn";
import { CATEGORIES } from "@/data";
import { Label, MaskText, PillButton, Reveal, Star4, useGoTo } from "@/components/ui";
import { ArrowUpRight } from "@/components/Icons";

export default function Categories() {
  const goTo = useGoTo();
  const [active, setActive] = useState(0);

  return (
    <section id="categories" className="relative bg-white/60 px-4 py-16 sm:px-8 lg:py-24">
      <div className="mb-10 flex items-end justify-between gap-6 lg:mb-14">
        <div>
          <Label>[CATÉGORIES]</Label>
          <MaskText
            className="mt-4 text-[clamp(2.6rem,10vw,4rem)] font-semibold leading-[0.9] tracking-[-0.055em] lg:text-[clamp(3.5rem,5.5vw,6rem)]"
            lines={[
              <>Nos univers,</>,
              <>
                votre <span className="serif-i text-ochre">signature</span>
              </>,
            ]}
          />
        </div>
        <span className="label hidden text-ink/50 md:block">06 catégories · 401 pièces</span>
      </div>

      <div className="grid gap-10 lg:grid-cols-12 lg:gap-12">
        {/* Photo */}
        <Reveal className="lg:col-span-5">
          <div className="lg:sticky lg:top-28">
            <div className="bevel relative aspect-[4/3] overflow-hidden bg-sand sm:aspect-[4/5]" style={{ ["--b" as string]: "36px" }}>
              {CATEGORIES.map((c, k) => (
                <img
                  key={c.name}
                  src={c.img}
                  alt={c.name}
                  loading="lazy"
                  className={cn(
                    "absolute inset-0 h-full w-full object-cover transition-all duration-[900ms] ease-[cubic-bezier(.2,.7,.2,1)]",
                    k === active ? "scale-100 opacity-100" : "scale-[1.08] opacity-0"
                  )}
                />
              ))}
              <span className="absolute inset-x-0 top-[62%] z-10 h-[2px] bg-ivory" />
              <div className="absolute left-4 top-4 z-10 rounded-full bg-ivory/90 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] backdrop-blur">
                [0{active + 1}] {CATEGORIES[active].name}
              </div>
              <div key={active} className="fade-up absolute bottom-4 left-4 right-4 z-10 flex items-center justify-between text-ivory">
                <span className="text-sm font-medium drop-shadow">{CATEGORIES[active].tag}</span>
                <span className="text-sm font-semibold drop-shadow">{CATEGORIES[active].count} articles</span>
              </div>
            </div>
            <div className="mt-6 flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
              <p className="max-w-xs text-[15px] leading-relaxed text-ink/70">
                <Star4 className="mr-2 inline h-3.5 w-3.5 -translate-y-0.5 text-ochre" />
                Chaque pièce raconte une histoire, entre tradition et modernité.
              </p>
              <PillButton onClick={() => goTo("produits")} variant="dark">
                Voir les produits
              </PillButton>
            </div>
          </div>
        </Reveal>

        {/* List */}
        <ul className="lg:col-span-7">
          {CATEGORIES.map((c, k) => {
            const on = k === active;
            return (
              <Reveal as="li" key={c.name} delay={k * 70}>
                <button
                  type="button"
                  onMouseEnter={() => setActive(k)}
                  onFocus={() => setActive(k)}
                  onClick={() => setActive(k)}
                  className={cn(
                    "group relative flex w-full items-center gap-4 border-b py-4 text-left transition-colors duration-500 sm:gap-6 sm:py-5",
                    on ? "border-ink" : "border-ink/10"
                  )}
                >
                  <span className={cn("label w-10 shrink-0 transition-colors duration-500", on ? "text-terra" : "text-ink/30")}>[0{k + 1}]</span>
                  <span
                    className={cn(
                      "flex-1 text-[clamp(2rem,8.5vw,3rem)] font-semibold leading-none tracking-[-0.05em] transition-all duration-500 lg:text-[clamp(2.6rem,4.6vw,4.8rem)]",
                      on ? "translate-x-1 text-ink sm:translate-x-3" : "text-ink/20"
                    )}
                  >
                    {k % 2 === 1 ? <span className={cn(on && "serif-i")}>{c.name}</span> : c.name}
                    <sup className={cn("ml-1.5 align-super text-[0.32em] font-medium tracking-normal transition-colors", on ? "text-ochre" : "text-ink/25")}>({c.count})</sup>
                  </span>
                  <span
                    className={cn(
                      "flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition-all duration-500 sm:h-14 sm:w-14",
                      on ? "rotate-0 bg-ochre text-white" : "-rotate-45 border border-ink/15 text-ink/30"
                    )}
                  >
                    <ArrowUpRight className="h-5 w-5" />
                  </span>
                </button>
              </Reveal>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
