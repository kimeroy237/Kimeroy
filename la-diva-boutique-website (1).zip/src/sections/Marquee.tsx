import { Fragment } from "react";
import { MARQUEE } from "@/data";
import { Star4 } from "@/components/ui";

function Row({ dark, reverse }: { dark?: boolean; reverse?: boolean }) {
  const items = [...MARQUEE, ...MARQUEE];
  return (
    <div className={dark ? "bg-ink text-ivory" : "bg-ochre text-ink"}>
      <div className={`marquee-track flex w-max items-center py-4 sm:py-5 ${reverse ? "reverse" : ""}`}>
        {[0, 1].map((dup) => (
          <div key={dup} className="flex shrink-0 items-center" aria-hidden={dup === 1}>
            {items.map((t, i) => (
              <Fragment key={`${dup}-${i}`}>
                <span className={`whitespace-nowrap px-4 text-[clamp(1.6rem,5vw,3.6rem)] font-semibold uppercase leading-none tracking-[-0.04em] sm:px-6 ${i % 3 === 1 ? "serif-i normal-case" : ""}`}>
                  {i % 3 === 1 ? t.toLowerCase() : t}
                </span>
                {i % 4 === 3 ? (
                  <Star4 className={`h-6 w-6 shrink-0 sm:h-8 sm:w-8 ${dark ? "text-ochre" : "text-ink"}`} />
                ) : (
                  <span className={`text-[clamp(1.6rem,5vw,3.6rem)] font-light leading-none ${dark ? "text-ochre" : "text-terra"}`}>+</span>
                )}
              </Fragment>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Marquee() {
  return (
    <section aria-label="Nos spécialités" className="relative overflow-hidden py-14 sm:py-20">
      <div className="-mx-4 rotate-[2deg]">
        <Row reverse />
      </div>
      <div className="relative z-10 -mx-4 -mt-12 -rotate-[2deg] shadow-[0_20px_40px_-20px_rgba(0,0,0,.4)] sm:-mt-16">
        <Row dark />
      </div>
    </section>
  );
}
