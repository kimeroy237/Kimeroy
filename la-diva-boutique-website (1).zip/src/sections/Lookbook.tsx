import { useEffect, useRef, useState } from "react";
import { cn } from "@/utils/cn";
import { LOOKBOOK } from "@/data";
import { Label, MaskText, RoundButton, Star4 } from "@/components/ui";
import { ArrowLeft, ArrowRight } from "@/components/Icons";

const GAP = 20;

export default function Lookbook() {
  const [i, setI] = useState(2);
  const [w, setW] = useState(300);
  const touch = useRef<number | null>(null);
  const n = LOOKBOOK.length;

  useEffect(() => {
    const calc = () => {
      const vw = window.innerWidth;
      setW(vw < 640 ? Math.round(vw * 0.66) : vw < 1024 ? 300 : Math.min(380, Math.round(vw * 0.24)));
    };
    calc();
    window.addEventListener("resize", calc);
    return () => window.removeEventListener("resize", calc);
  }, []);

  const go = (d: number) => setI((v) => Math.min(n - 1, Math.max(0, v + d)));

  return (
    <section id="lookbook" className="relative overflow-hidden bg-ink py-16 text-ivory lg:py-24">
      <div className="flex flex-col gap-6 px-4 sm:px-8 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <Label className="text-ivory/50">//GALERIE</Label>
          <MaskText
            className="mt-4 text-[clamp(2.6rem,11vw,4.5rem)] font-semibold leading-[0.9] tracking-[-0.06em] lg:text-[clamp(3.5rem,6vw,6.5rem)]"
            lines={[
              <>©la diva</>,
              <>
                <span className="text-ochre">-</span> <span className="serif-i">lookbook</span>
              </>,
            ]}
          />
        </div>
        <div className="flex items-end justify-between gap-6 lg:flex-col lg:items-end">
          <span className="text-outline text-[clamp(3.5rem,12vw,8rem)] font-bold leading-[0.8] tracking-[-0.06em] text-ivory/70">2026</span>
          <div className="flex items-center gap-3">
            <span className="label mr-2 text-ivory/50">
              {String(i + 1).padStart(2, "0")} / {String(n).padStart(2, "0")}
            </span>
            <RoundButton label="Image précédente" onClick={() => go(-1)} className="h-12 w-12 border-ivory/30 text-ivory hover:border-ivory hover:bg-ivory hover:text-ink">
              <ArrowLeft className="h-5 w-5" />
            </RoundButton>
            <RoundButton label="Image suivante" onClick={() => go(1)} className="h-12 w-12 border-ochre bg-ochre text-white hover:border-ivory hover:bg-ivory hover:text-ink">
              <ArrowRight className="h-5 w-5" />
            </RoundButton>
          </div>
        </div>
      </div>

      <div
        className="relative mt-12 select-none"
        onTouchStart={(e) => (touch.current = e.touches[0].clientX)}
        onTouchEnd={(e) => {
          if (touch.current === null) return;
          const dx = e.changedTouches[0].clientX - touch.current;
          if (Math.abs(dx) > 40) go(dx < 0 ? 1 : -1);
          touch.current = null;
        }}
      >
        <div
          className="flex items-center transition-transform duration-[900ms] ease-[cubic-bezier(.2,.7,.2,1)]"
          style={{ marginLeft: "50%", gap: GAP, transform: `translateX(${-(i * (w + GAP) + w / 2)}px)` }}
        >
          {LOOKBOOK.map((l, k) => {
            const on = k === i;
            return (
              <button
                key={k}
                type="button"
                onClick={() => setI(k)}
                aria-label={`${l.title} — ${l.type}`}
                className={cn(
                  "relative shrink-0 text-left transition-all duration-[900ms] ease-[cubic-bezier(.2,.7,.2,1)]",
                  on ? "scale-100 opacity-100 blur-0" : "scale-[0.86] opacity-50 blur-[5px] hover:opacity-80"
                )}
                style={{ width: w }}
              >
                <div className={cn("relative aspect-[3/4.3] overflow-hidden bg-[#222]", k % 2 ? "bevel-alt" : "bevel")} style={{ ["--b" as string]: "32px" }}>
                  <img src={l.img} alt={l.title} loading="lazy" draggable={false} className="absolute inset-0 h-full w-full object-cover" />
                  <span className="absolute inset-x-0 top-[66%] h-[2px] bg-ink" />
                  <span className="label absolute left-4 top-4 rounded-full bg-ink/70 px-2.5 py-1 text-[10px] text-ivory backdrop-blur">{l.type}</span>
                </div>
                <div className={cn("mt-4 flex items-center justify-between transition-opacity duration-500", on ? "opacity-100" : "opacity-0")}>
                  <span className="text-lg font-semibold tracking-tight">{l.title}</span>
                  <Star4 className="h-4 w-4 text-ochre" />
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-10 flex justify-center gap-1.5 px-4">
        {LOOKBOOK.map((_, k) => (
          <button
            key={k}
            type="button"
            aria-label={`Aller à l'image ${k + 1}`}
            onClick={() => setI(k)}
            className={cn("h-1.5 rounded-full transition-all duration-500", k === i ? "w-8 bg-ochre" : "w-1.5 bg-ivory/30")}
          />
        ))}
      </div>
    </section>
  );
}
