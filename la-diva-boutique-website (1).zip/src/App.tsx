import { useCallback, useEffect, useRef, useState } from "react";
import { NavCtx, SectionDivider, Star4 } from "@/components/ui";
import { WhatsAppIcon } from "@/components/Icons";
import { waLink } from "@/data";
import Header from "@/sections/Header";
import Hero from "@/sections/Hero";
import Occasions from "@/sections/Occasions";
import Categories from "@/sections/Categories";
import Marquee from "@/sections/Marquee";
import Products from "@/sections/Products";
import Testimonials from "@/sections/Testimonials";
import Lookbook from "@/sections/Lookbook";
import Collections from "@/sections/Collections";
import CtaBanner from "@/sections/CtaBanner";
import Footer from "@/sections/Footer";

function useParallax() {
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let raf = 0;
    const update = () => {
      raf = 0;
      const vh = window.innerHeight;
      document.querySelectorAll<HTMLElement>("[data-parallax]").forEach((el) => {
        const host = el.parentElement;
        if (!host) return;
        const r = host.getBoundingClientRect();
        if (r.bottom < -100 || r.top > vh + 100) return;
        const speed = Number(el.dataset.parallax) || 30;
        const p = (r.top + r.height / 2 - vh / 2) / vh; // -1 … 1
        el.style.transform = `translate3d(0, ${(-p * speed).toFixed(1)}px, 0)`;
      });
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);
}

export default function App() {
  const [wipe, setWipe] = useState(0);
  const timers = useRef<number[]>([]);
  useParallax();

  const goTo = useCallback((id: string) => {
    const el = document.getElementById(id);
    if (!el) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      el.scrollIntoView();
      return;
    }
    timers.current.forEach(clearTimeout);
    setWipe((w) => w + 1);
    timers.current = [
      window.setTimeout(() => {
        const y = el.getBoundingClientRect().top + window.scrollY - (id === "accueil" ? 0 : 70);
        window.scrollTo({ top: id === "accueil" ? 0 : y, behavior: "instant" as ScrollBehavior });
      }, 460),
    ];
  }, []);

  return (
    <NavCtx.Provider value={goTo}>
      {/* Black strip page transition */}
      {wipe > 0 && (
        <div key={wipe} className="page-wipe pointer-events-none fixed inset-0 z-[70] flex items-center justify-center bg-ink" aria-hidden="true">
          <span className="flex items-center gap-3 text-3xl font-extrabold tracking-[-0.04em] text-ivory sm:text-5xl">
            LA <Star4 className="h-5 w-5 text-ochre sm:h-7 sm:w-7" /> DIVA
          </span>
        </div>
      )}

      <div className="p-2 sm:p-3 lg:p-4">
        <div className="relative mx-auto max-w-[1680px] overflow-clip rounded-[24px] bg-ivory shadow-[0_30px_80px_-40px_rgba(17,17,17,.35)] sm:rounded-[36px]">
          <Header />
          <main>
            <Hero />
            <SectionDivider />
            <Occasions />
            <SectionDivider />
            <Categories />
            <Marquee />
            <Products />
            <SectionDivider />
            <Testimonials />
            <Lookbook />
            <Collections />
            <CtaBanner />
          </main>
          <Footer />
        </div>
      </div>

      {/* Floating WhatsApp button */}
      <a
        href={waLink()}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Commander sur WhatsApp"
        className="wa-pulse group fixed bottom-5 right-5 z-50 isolate flex h-14 w-14 items-center justify-center rounded-full bg-wa text-white shadow-[0_10px_30px_-8px_rgba(37,211,102,.9)] transition-transform hover:scale-105 sm:bottom-7 sm:right-7 sm:h-16 sm:w-16"
      >
        <WhatsAppIcon className="h-7 w-7 sm:h-8 sm:w-8" />
        <span className="pointer-events-none absolute right-full mr-3 hidden whitespace-nowrap rounded-full bg-ink px-4 py-2 text-xs font-semibold text-ivory opacity-0 transition group-hover:opacity-100 sm:block">
          Commandez sur WhatsApp
        </span>
      </a>
    </NavCtx.Provider>
  );
}
